'use strict';

/* ---------- tiny helpers ---------- */
const $ = (sel) => document.querySelector(sel);
function h(tag, attrs, ...kids) {
  const el = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs || {})) {
    if (v === false || v == null) continue;
    if (k === 'class') el.className = v;
    else if (k.startsWith('on')) el.addEventListener(k.slice(2), v);
    else el.setAttribute(k, v === true ? '' : v);
  }
  for (const kid of kids.flat()) el.append(kid instanceof Node ? kid : document.createTextNode(String(kid ?? '')));
  return el;
}
const fmtBytes = (n) => (n < 1024 ? `${n} B` : n < 1048576 ? `${(n / 1024).toFixed(1)} KB` : `${(n / 1048576).toFixed(1)} MB`);
const fmtTime = (iso) => (iso ? new Date(iso).toLocaleString() : '-');
const badge = (text, cls) => h('span', { class: `badge ${cls || text}` }, text);

async function api(method, url, body) {
  const res = await fetch(url, {
    method,
    headers: body ? { 'Content-Type': 'application/json' } : undefined,
    body: body ? JSON.stringify(body) : undefined,
  });
  let data = null;
  try { data = await res.json(); } catch { /* empty body */ }
  if (!res.ok) throw new Error((data && data.error) || `Request failed (${res.status})`);
  return data;
}

function toast(message, type = 'info') {
  const t = h('div', { class: `toast ${type}` }, message);
  $('#toasts').append(t);
  setTimeout(() => t.remove(), 4500);
}

async function run(button, fn, okMessage) {
  if (button) button.disabled = true;
  try {
    const result = await fn();
    if (okMessage) toast(okMessage, 'success');
    return result;
  } catch (e) {
    toast(e.message, 'error');
  } finally {
    if (button) button.disabled = false;
    refreshAll();
  }
}

/* ---------- state ---------- */
const state = { backups: [], verifyCache: new Map(), tab: 'backups', dialogId: null };

/* ---------- stats and timeline ---------- */
async function loadStatus() {
  const s = await api('GET', '/api/status');
  const items = [
    ['Backups', s.backups], ['Verified', s.verified], ['Corrupted', s.corrupted, s.corrupted > 0],
    ['Failures logged', s.failures, s.failures > 0], ['Source files', s.sourceFiles], ['Stored', fmtBytes(s.backupBytes)],
  ];
  $('#stats').replaceChildren(...items.map(([label, value, bad]) =>
    h('div', {}, h('dt', {}, label), h('dd', { class: bad ? 'bad' : '' }, value))));
}

function renderTimeline() {
  const box = $('#timeline');
  if (!state.backups.length) { box.replaceChildren(h('span', { class: 'empty' }, 'No backups yet. Use "Back up now" to create the first one.')); return; }
  const max = Math.max(...state.backups.map((b) => b.totalSize), 1);
  const segs = [...state.backups].reverse().map((b) => {
    const height = 18 + Math.round((b.totalSize / max) * 40);
    return h('button', {
      class: `seg ${b.verifyStatus.toLowerCase()}`, style: `height:${height}px`, type: 'button',
      title: `${b.label} - ${fmtTime(b.createdAt)} - ${b.verifyStatus}`, 'aria-label': `Open backup ${b.id}`,
      onclick: () => openDetails(b.id),
    });
  });
  box.replaceChildren(...segs);
  box.scrollLeft = box.scrollWidth;
}

/* ---------- backups table ---------- */
async function loadBackups() {
  state.backups = await api('GET', '/api/backups');
  const rows = $('#backup-rows');
  if (!state.backups.length) {
    rows.replaceChildren(h('tr', {}, h('td', { class: 'empty', colspan: 7 }, 'No backups yet.')));
  } else {
    rows.replaceChildren(...state.backups.map((b) => h('tr', {},
      h('td', {}, b.label, h('span', { class: 'sub mono' }, b.id)),
      h('td', {}, fmtTime(b.createdAt)),
      h('td', {}, b.trigger),
      h('td', {}, b.fileCount),
      h('td', {}, fmtBytes(b.totalSize)),
      h('td', {}, badge(b.verifyStatus), h('span', { class: 'sub' }, b.lastVerified ? `checked ${fmtTime(b.lastVerified)}` : 'never checked')),
      h('td', { class: 'actions' },
        h('button', { type: 'button', onclick: (e) => verify(b.id, e.target) }, 'Verify'),
        h('button', { type: 'button', onclick: () => openDetails(b.id) }, 'Details'),
        h('button', { type: 'button', onclick: (e) => restore(b.id, null, 'restored', e.target) }, 'Restore'),
        h('button', { type: 'button', class: 'danger', onclick: (e) => removeBackup(b, e.target) }, 'Delete')))));
  }
  renderTimeline();
}

async function verify(id, btn, openAfter = true) {
  const r = await run(btn, () => api('POST', `/api/backups/${id}/verify`));
  if (!r) return;
  state.verifyCache.set(id, r);
  toast(r.failed ? `Integrity check failed: ${r.failed} of ${r.checked} file(s) damaged` : `All ${r.checked} file(s) verified`, r.failed ? 'error' : 'success');
  if (openAfter || state.dialogId === id) { await loadBackups(); openDetails(id); }
}

async function restore(id, file, target, btn) {
  if (target === 'source' && !confirm('This overwrites matching files in data/source with the backup copies. Continue?')) return;
  const r = await run(btn, () => api('POST', `/api/backups/${id}/restore`, { file: file || undefined, target }));
  if (!r) return;
  if (r.ok) toast(`Restored ${r.restored} file(s) to data/${r.destination}`, 'success');
  else toast(`Restore incomplete: ${r.restored} restored, ${r.failed} refused or failed. See the failure log.`, 'error');
  showRestoreResult(r);
}

async function removeBackup(b, btn) {
  if (!confirm(`Delete backup "${b.label}" (${b.id})? This cannot be undone.`)) return;
  await run(btn, () => api('DELETE', `/api/backups/${b.id}`), 'Backup deleted');
  if (state.dialogId === b.id) closeDialog();
}

$('#backup-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const label = $('#backup-label').value.trim() || 'Manual backup';
  const r = await run(e.submitter, () => api('POST', '/api/backups', { label }), 'Backup created');
  if (r) $('#backup-label').value = '';
});

/* ---------- dialog ---------- */
function closeDialog() { state.dialogId = null; $('#dialog').close(); }
function showDialog(...nodes) { $('#dialog-body').replaceChildren(...nodes); if (!$('#dialog').open) $('#dialog').showModal(); }
$('#dialog').addEventListener('close', () => { state.dialogId = null; });
$('#dialog').addEventListener('click', (e) => { if (e.target.id === 'dialog') closeDialog(); });

async function openDetails(id) {
  let b;
  try { b = await api('GET', `/api/backups/${id}`); } catch (e) { toast(e.message, 'error'); return; }
  state.dialogId = id;
  const cached = state.verifyCache.get(id);
  const statusOf = (path) => (cached ? (cached.results.find((r) => r.path === path) || {}).status : null);
  const mode = h('select', { id: 'corrupt-mode', 'aria-label': 'Corruption type' },
    h('option', { value: 'flip' }, 'Flip one byte'), h('option', { value: 'truncate' }, 'Truncate file'), h('option', { value: 'delete' }, 'Delete file'));
  const target = h('select', { id: 'restore-target', 'aria-label': 'Restore destination' },
    h('option', { value: 'restored' }, 'Restore to data/restored (safe)'), h('option', { value: 'source' }, 'Overwrite data/source'));

  const rows = b.files.map((f) => h('tr', {},
    h('td', {}, f.path, h('span', { class: 'sub mono hash' }, f.sha256)),
    h('td', {}, fmtBytes(f.size)),
    h('td', {}, statusOf(f.path) ? badge(statusOf(f.path)) : badge('Not checked', 'UNVERIFIED')),
    h('td', { class: 'actions' },
      h('button', { type: 'button', onclick: (e) => restore(id, f.path, target.value, e.target) }, 'Restore'),
      h('button', { type: 'button', class: 'danger', onclick: async (e) => {
        const r = await run(e.target, () => api('POST', `/api/backups/${id}/corrupt`, { file: f.path, mode: mode.value }));
        if (r) { toast(`Simulated ${r.mode} on ${r.file}. Verify the backup to detect it.`, 'info'); }
      } }, 'Corrupt'))));

  showDialog(
    h('div', { class: 'dlg-head' },
      h('div', {}, h('h2', {}, b.label), h('span', { class: 'sub mono' }, b.id), h('span', { class: 'sub' }, `${fmtTime(b.createdAt)} - ${b.trigger} - ${b.fileCount} files - ${fmtBytes(b.totalSize)}`)),
      h('button', { type: 'button', onclick: closeDialog }, 'Close')),
    h('div', {}, badge(b.verifyStatus)),
    h('div', { class: 'dlg-tools' },
      h('button', { type: 'button', class: 'primary', onclick: (e) => verify(id, e.target, false) }, 'Verify SHA-256'),
      h('label', {}, 'Corruption type', mode),
      h('label', {}, 'Restore destination', target),
      h('button', { type: 'button', onclick: async (e) => {
        const r = await run(e.target, () => api('POST', `/api/backups/${id}/corrupt`, { mode: mode.value }));
        if (r) toast(`Simulated ${r.mode} on ${r.file}. Verify the backup to detect it.`, 'info');
      } }, 'Corrupt a random file'),
      h('button', { type: 'button', onclick: (e) => restore(id, null, target.value, e.target) }, 'Restore all files')),
    h('div', { class: 'table-wrap' }, h('table', {},
      h('thead', {}, h('tr', {}, h('th', {}, 'File and SHA-256'), h('th', {}, 'Size'), h('th', {}, 'Last check'), h('th', { class: 'actions-col' }, 'Actions'))),
      h('tbody', {}, rows))));
}

function showRestoreResult(r) {
  state.dialogId = null;
  showDialog(
    h('div', { class: 'dlg-head' }, h('h2', {}, 'Restore result'), h('button', { type: 'button', onclick: closeDialog }, 'Close')),
    h('div', { class: `summary ${r.ok ? 'ok' : 'bad'}` }, r.ok ? `${r.restored} file(s) restored to data/${r.destination}` : `${r.restored} restored, ${r.failed} not restored`),
    h('div', { class: 'table-wrap' }, h('table', {},
      h('thead', {}, h('tr', {}, h('th', {}, 'File'), h('th', {}, 'Result'), h('th', {}, 'Detail'))),
      h('tbody', {}, r.results.map((x) => h('tr', {}, h('td', {}, x.path), h('td', {}, badge(x.status)), h('td', { class: 'mono hash' }, x.reason || x.sha256 || '')))))));
}

/* ---------- source files ---------- */
async function loadSource() {
  const files = await api('GET', '/api/source');
  $('#source-rows').replaceChildren(...(files.length ? files.map((f) => h('tr', {},
    h('td', { class: 'mono' }, f.path), h('td', {}, fmtBytes(f.size)), h('td', {}, fmtTime(f.modified)),
    h('td', { class: 'actions' }, h('button', { type: 'button', class: 'danger', onclick: async (e) => {
      if (confirm(`Delete source file ${f.path}? Use this to simulate data loss, then restore it from a backup.`)) {
        await run(e.target, () => api('DELETE', `/api/source?name=${encodeURIComponent(f.path)}`), 'Source file deleted');
      }
    } }, 'Delete')))) : [h('tr', {}, h('td', { class: 'empty', colspan: 4 }, 'Source folder is empty. Add a file below, or restore one from a backup.'))]));
}

$('#source-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const r = await run(e.submitter, () => api('POST', '/api/source', { name: $('#source-name').value.trim(), content: $('#source-content').value }), 'File saved');
  if (r) { $('#source-name').value = ''; $('#source-content').value = ''; }
});

/* ---------- schedules ---------- */
async function loadSchedules() {
  const list = await api('GET', '/api/schedules');
  $('#schedule-rows').replaceChildren(...(list.length ? list.map((s) => h('tr', {},
    h('td', {}, s.label, s.verifyAfter ? h('span', { class: 'sub' }, 'verifies after backup') : ''),
    h('td', {}, `${s.intervalSec}s`),
    h('td', {}, s.enabled ? fmtTime(s.nextRun) : badge('paused', 'paused')),
    h('td', {}, fmtTime(s.lastRun), s.lastError ? h('span', { class: 'sub' }, s.lastError) : ''),
    h('td', {}, s.running ? badge('RUNNING', 'WARN') : s.lastStatus ? badge(s.lastStatus) : '-'),
    h('td', {}, s.runCount),
    h('td', { class: 'actions' },
      h('button', { type: 'button', onclick: (e) => run(e.target, () => api('POST', `/api/schedules/${s.id}/run`), 'Schedule ran') }, 'Run now'),
      h('button', { type: 'button', onclick: (e) => run(e.target, () => api('PATCH', `/api/schedules/${s.id}`, { enabled: !s.enabled })) }, s.enabled ? 'Pause' : 'Resume'),
      h('button', { type: 'button', class: 'danger', onclick: (e) => run(e.target, () => api('DELETE', `/api/schedules/${s.id}`), 'Schedule removed') }, 'Remove')))) :
    [h('tr', {}, h('td', { class: 'empty', colspan: 7 }, 'No schedules yet. Add one above to back up automatically.'))]));
}

$('#schedule-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  await run(e.submitter, () => api('POST', '/api/schedules', {
    label: $('#sch-label').value.trim() || 'Scheduled backup',
    intervalSec: Number($('#sch-interval').value),
    verifyAfter: $('#sch-verify').checked,
  }), 'Schedule added');
});

/* ---------- logs ---------- */
async function loadLogs() {
  const kind = $('#log-kind').value;
  const logs = await api('GET', `/api/logs?kind=${kind}&limit=150`);
  $('#log-rows').replaceChildren(...(logs.length ? logs.map((l) => h('tr', {},
    h('td', { class: 'mono' }, fmtTime(l.time)), h('td', {}, badge(l.level)), h('td', { class: 'mono' }, l.event), h('td', {}, l.message)))
    : [h('tr', {}, h('td', { class: 'empty', colspan: 4 }, kind === 'failures' ? 'No failures recorded.' : 'No events recorded.'))]));
}
$('#log-kind').addEventListener('change', loadLogs);
$('#log-clear').addEventListener('click', async (e) => {
  const kind = $('#log-kind').value;
  if (confirm(`Clear the ${kind} log?`)) await run(e.target, () => api('DELETE', `/api/logs?kind=${kind}`), 'Log cleared');
});

/* ---------- tabs and refresh ---------- */
document.querySelectorAll('.tabs button').forEach((btn) => btn.addEventListener('click', () => {
  state.tab = btn.dataset.tab;
  document.querySelectorAll('.tabs button').forEach((b) => b.setAttribute('aria-selected', String(b === btn)));
  document.querySelectorAll('.panel').forEach((p) => { p.hidden = p.id !== `tab-${state.tab}`; });
  refreshAll();
}));

let refreshing = false;
async function refreshAll() {
  if (refreshing) return;
  refreshing = true;
  try {
    await loadStatus();
    await loadBackups();
    if (state.tab === 'source') await loadSource();
    if (state.tab === 'schedules') await loadSchedules();
    if (state.tab === 'logs') await loadLogs();
  } catch (e) {
    console.error(e);
  } finally { refreshing = false; }
}

refreshAll();
setInterval(() => { if (!$('#dialog').open) refreshAll(); }, 3000);
