'use strict';
const fs = require('node:fs');
const fsp = fs.promises;
const path = require('node:path');
const crypto = require('node:crypto');
const { sha256File } = require('./hashUtil');
const { AppError } = require('./errors');

const ID_RE = /^bk-\d{8}-\d{6}-[a-f0-9]{4}$/;
const MAX_SOURCE_FILE_BYTES = 1024 * 1024; // 1 MB for files created through the UI

class BackupManager {
  constructor({ dataDir, logger, maxBackups = 50 }) {
    this.dataDir = dataDir;
    this.sourceDir = path.join(dataDir, 'source');
    this.backupDir = path.join(dataDir, 'backups');
    this.restoreDir = path.join(dataDir, 'restored');
    this.logger = logger;
    this.maxBackups = maxBackups;
    [this.sourceDir, this.backupDir, this.restoreDir].forEach((d) => fs.mkdirSync(d, { recursive: true }));
  }

  /* ---------- path safety helpers ---------- */

  _checkId(id) {
    if (typeof id !== 'string' || !ID_RE.test(id)) throw new AppError(400, 'BAD_ID', 'Invalid backup id');
  }

  _safeRel(rel) {
    if (typeof rel !== 'string' || !rel.trim()) throw new AppError(400, 'BAD_PATH', 'File path is required');
    const norm = path.posix.normalize(rel.replace(/\\/g, '/'));
    if (norm === '.' || path.posix.isAbsolute(norm) || norm.split('/').includes('..')) {
      throw new AppError(400, 'BAD_PATH', 'File path must stay inside the folder');
    }
    return norm;
  }

  _inside(base, rel) {
    const root = path.resolve(base);
    const full = path.resolve(root, ...rel.split('/'));
    if (!full.startsWith(root + path.sep)) throw new AppError(400, 'BAD_PATH', 'Path escapes the folder');
    return full;
  }

  _newId() {
    const d = new Date();
    const p = (n) => String(n).padStart(2, '0');
    const stamp = `${d.getUTCFullYear()}${p(d.getUTCMonth() + 1)}${p(d.getUTCDate())}-${p(d.getUTCHours())}${p(d.getUTCMinutes())}${p(d.getUTCSeconds())}`;
    return `bk-${stamp}-${crypto.randomBytes(2).toString('hex')}`;
  }

  async _walk(base, prefix = '') {
    const out = [];
    let entries;
    try { entries = await fsp.readdir(path.join(base, prefix), { withFileTypes: true }); }
    catch (e) { if (e.code === 'ENOENT') return out; throw e; }
    for (const ent of entries) {
      if (ent.name === '.gitkeep') continue;
      const rel = prefix ? `${prefix}/${ent.name}` : ent.name;
      if (ent.isDirectory()) out.push(...(await this._walk(base, rel)));
      else if (ent.isFile()) out.push(rel);
    }
    return out.sort();
  }

  /* ---------- source folder (the data being protected) ---------- */

  async listSource() {
    const files = await this._walk(this.sourceDir);
    const out = [];
    for (const rel of files) {
      const st = await fsp.stat(this._inside(this.sourceDir, rel));
      out.push({ path: rel, size: st.size, modified: st.mtime.toISOString() });
    }
    return out;
  }

  async writeSourceFile(name, content) {
    const rel = this._safeRel(name);
    if (typeof content !== 'string') throw new AppError(400, 'BAD_CONTENT', 'Content must be text');
    if (Buffer.byteLength(content) > MAX_SOURCE_FILE_BYTES) throw new AppError(413, 'TOO_LARGE', 'File is larger than 1 MB');
    const full = this._inside(this.sourceDir, rel);
    await fsp.mkdir(path.dirname(full), { recursive: true });
    await fsp.writeFile(full, content);
    this.logger.info('SOURCE_SAVED', `Source file saved: ${rel}`, { path: rel });
    return { path: rel };
  }

  async deleteSourceFile(name) {
    const rel = this._safeRel(name);
    try { await fsp.unlink(this._inside(this.sourceDir, rel)); }
    catch (e) { if (e.code === 'ENOENT') throw new AppError(404, 'NOT_FOUND', 'Source file not found'); throw e; }
    this.logger.info('SOURCE_DELETED', `Source file deleted: ${rel}`, { path: rel });
  }

  /* ---------- manifests ---------- */

  async _readManifest(id) {
    this._checkId(id);
    try {
      return JSON.parse(await fsp.readFile(path.join(this.backupDir, id, 'manifest.json'), 'utf8'));
    } catch (e) {
      if (e.code === 'ENOENT') throw new AppError(404, 'NOT_FOUND', `Backup ${id} not found`);
      throw new AppError(500, 'BAD_MANIFEST', `Manifest of ${id} is unreadable`);
    }
  }

  async _writeManifest(id, manifest) {
    const file = path.join(this.backupDir, id, 'manifest.json');
    const tmp = file + '.tmp';
    await fsp.writeFile(tmp, JSON.stringify(manifest, null, 2));
    await fsp.rename(tmp, file);
  }

  _backupFile(id, rel) {
    return this._inside(path.join(this.backupDir, id, 'files'), this._safeRel(rel));
  }

  /* ---------- create ---------- */

  async createBackup({ label = 'Manual backup', trigger = 'manual' } = {}) {
    label = String(label || 'Manual backup').slice(0, 80);
    const files = await this._walk(this.sourceDir);
    if (!files.length) {
      const err = new AppError(422, 'NO_SOURCE_FILES', 'Source folder is empty - nothing to back up');
      this.logger.error('BACKUP_FAILED', err.message, { trigger, label });
      throw err;
    }

    const id = this._newId();
    const dir = path.join(this.backupDir, id);
    const entries = [];
    try {
      await fsp.mkdir(path.join(dir, 'files'), { recursive: true });
      for (const rel of files) {
        const src = this._inside(this.sourceDir, rel);
        const dst = this._backupFile(id, rel);
        await fsp.mkdir(path.dirname(dst), { recursive: true });
        const srcHash = await sha256File(src);
        await fsp.copyFile(src, dst);
        const dstHash = await sha256File(dst); // read-after-write check
        if (srcHash !== dstHash) throw new AppError(500, 'COPY_MISMATCH', `Copy of ${rel} does not match the source`);
        const st = await fsp.stat(dst);
        entries.push({ path: rel, size: st.size, sha256: srcHash });
      }
      const manifest = {
        id, label, trigger,
        createdAt: new Date().toISOString(),
        algorithm: 'SHA-256',
        fileCount: entries.length,
        totalSize: entries.reduce((s, f) => s + f.size, 0),
        verifyStatus: 'UNVERIFIED',
        lastVerified: null,
        files: entries,
      };
      await this._writeManifest(id, manifest);
      this.logger.info('BACKUP_CREATED', `Backup ${id} created (${entries.length} files, ${trigger})`, { id, trigger, label });
      await this._prune();
      return manifest;
    } catch (e) {
      await fsp.rm(dir, { recursive: true, force: true });
      this.logger.error('BACKUP_FAILED', `Backup failed: ${e.message}`, { id, trigger, label });
      throw e instanceof AppError ? e : new AppError(500, 'BACKUP_FAILED', e.message);
    }
  }

  /* ---------- history ---------- */

  async listBackups() {
    let names = [];
    try { names = await fsp.readdir(this.backupDir); } catch { return []; }
    const out = [];
    for (const name of names) {
      if (!ID_RE.test(name)) continue;
      try { out.push(await this._readManifest(name)); }
      catch { this.logger.warn('MANIFEST_UNREADABLE', `Skipping ${name}: manifest unreadable`, { id: name }); }
    }
    return out.sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  }

  getBackup(id) { return this._readManifest(id); }

  async deleteBackup(id) {
    await this._readManifest(id);
    await fsp.rm(path.join(this.backupDir, id), { recursive: true, force: true });
    this.logger.info('BACKUP_DELETED', `Backup ${id} deleted`, { id });
  }

  async _prune() {
    const all = await this.listBackups();
    const extra = all.slice(this.maxBackups);
    for (const m of extra) {
      await fsp.rm(path.join(this.backupDir, m.id), { recursive: true, force: true });
      this.logger.info('BACKUP_PRUNED', `Retention limit reached - removed ${m.id}`, { id: m.id });
    }
  }

  /* ---------- verify (SHA-256) ---------- */

  async _checkFile(id, f) {
    let actual = null;
    let status;
    try {
      actual = await sha256File(this._backupFile(id, f.path));
      status = actual === f.sha256 ? 'OK' : 'CORRUPTED';
    } catch (e) {
      if (e.code === 'ENOENT') status = 'MISSING'; else throw e;
    }
    return { path: f.path, status, expected: f.sha256, actual };
  }

  async verifyBackup(id) {
    const m = await this._readManifest(id);
    const results = [];
    for (const f of m.files) results.push(await this._checkFile(id, f));
    const bad = results.filter((r) => r.status !== 'OK');
    m.verifyStatus = bad.length ? 'CORRUPTED' : 'VERIFIED';
    m.lastVerified = new Date().toISOString();
    await this._writeManifest(id, m);
    if (bad.length) {
      this.logger.error('INTEGRITY_FAILURE', `Backup ${id}: ${bad.length} of ${results.length} file(s) failed SHA-256 verification`,
        { id, files: bad.map((b) => ({ path: b.path, status: b.status })) });
    } else {
      this.logger.info('VERIFY_OK', `Backup ${id} verified: all ${results.length} file(s) match`, { id });
    }
    return { id, status: m.verifyStatus, checked: results.length, failed: bad.length, results };
  }

  /* ---------- corruption simulation ---------- */

  async simulateCorruption(id, { file, mode = 'flip' } = {}) {
    const m = await this._readManifest(id);
    if (!['flip', 'truncate', 'delete'].includes(mode)) throw new AppError(400, 'BAD_MODE', 'mode must be flip, truncate or delete');
    let target;
    if (file) {
      target = m.files.find((f) => f.path === file);
      if (!target) throw new AppError(404, 'NOT_FOUND', `File ${file} is not part of ${id}`);
    } else {
      target = m.files[crypto.randomInt(m.files.length)];
    }
    const full = this._backupFile(id, target.path);
    let size;
    try { size = (await fsp.stat(full)).size; }
    catch (e) { if (e.code === 'ENOENT') throw new AppError(409, 'ALREADY_MISSING', `${target.path} is already missing`); throw e; }

    if (mode === 'delete') {
      await fsp.unlink(full);
    } else if (size === 0) {
      await fsp.appendFile(full, Buffer.from([0x58]));
    } else if (mode === 'truncate') {
      await fsp.truncate(full, Math.floor(size / 2));
    } else {
      const fh = await fsp.open(full, 'r+');
      try {
        const off = crypto.randomInt(size);
        const b = Buffer.alloc(1);
        await fh.read(b, 0, 1, off);
        b[0] ^= 0xff; // flip every bit of one byte
        await fh.write(b, 0, 1, off);
      } finally { await fh.close(); }
    }
    this.logger.warn('CORRUPTION_SIMULATED', `Simulated ${mode} corruption on ${target.path} in ${id}`, { id, path: target.path, mode });
    return { id, file: target.path, mode };
  }

  /* ---------- restore ---------- */

  async restoreBackup(id, { file, target = 'restored' } = {}) {
    const m = await this._readManifest(id);
    if (!['restored', 'source'].includes(target)) throw new AppError(400, 'BAD_TARGET', 'target must be restored or source');
    const selected = file ? m.files.filter((f) => f.path === file) : m.files;
    if (!selected.length) throw new AppError(404, 'NOT_FOUND', `File ${file} is not part of ${id}`);

    const stamp = new Date().toISOString().replace(/[:.]/g, '-');
    const destName = target === 'source' ? 'source' : path.join('restored', `${id}_${stamp}`);
    const destBase = target === 'source' ? this.sourceDir : path.join(this.restoreDir, `${id}_${stamp}`);
    const results = [];

    for (const f of selected) {
      const check = await this._checkFile(id, f);
      if (check.status !== 'OK') {
        results.push({ path: f.path, status: 'SKIPPED', reason: `Backup copy is ${check.status} - restore refused` });
        continue;
      }
      try {
        const dst = this._inside(destBase, f.path);
        await fsp.mkdir(path.dirname(dst), { recursive: true });
        await fsp.copyFile(this._backupFile(id, f.path), dst);
        const h = await sha256File(dst);
        if (h !== f.sha256) throw new Error('hash mismatch after copy');
        results.push({ path: f.path, status: 'RESTORED', sha256: h });
      } catch (e) {
        results.push({ path: f.path, status: 'FAILED', reason: e.message });
      }
    }

    const restored = results.filter((r) => r.status === 'RESTORED').length;
    const failed = results.length - restored;
    if (failed) {
      this.logger.error('RESTORE_FAILED', `Restore of ${id}: ${failed} of ${results.length} file(s) could not be restored`,
        { id, target, files: results.filter((r) => r.status !== 'RESTORED').map((r) => ({ path: r.path, status: r.status })) });
    } else {
      this.logger.info('RESTORE_OK', `Restore of ${id}: ${restored} file(s) restored to ${destName}`, { id, target });
    }
    return { id, target, destination: restored ? destName.replace(/\\/g, '/') : null, ok: failed === 0, restored, failed, results };
  }

  /* ---------- stats ---------- */

  async stats() {
    const backups = await this.listBackups();
    const source = await this.listSource();
    return {
      sourceFiles: source.length,
      sourceBytes: source.reduce((s, f) => s + f.size, 0),
      backups: backups.length,
      backupBytes: backups.reduce((s, b) => s + b.totalSize, 0),
      verified: backups.filter((b) => b.verifyStatus === 'VERIFIED').length,
      corrupted: backups.filter((b) => b.verifyStatus === 'CORRUPTED').length,
      failures: this.logger.count('failures'),
      lastBackup: backups[0] ? backups[0].createdAt : null,
    };
  }
}

module.exports = BackupManager;
