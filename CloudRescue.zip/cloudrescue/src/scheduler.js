'use strict';
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { AppError } = require('./errors');

const MIN_INTERVAL = 5;        // seconds
const MAX_INTERVAL = 604800;   // 7 days

/** Interval-based scheduler. A single 1-second tick checks which schedules are due. */
class Scheduler {
  constructor({ dataDir, manager, logger, tickMs = 1000 }) {
    this.file = path.join(dataDir, 'schedules.json');
    this.manager = manager;
    this.logger = logger;
    this.tickMs = tickMs;
    this.running = new Set();
    this.timer = null;
    this.schedules = this._load();
  }

  _load() {
    try { return JSON.parse(fs.readFileSync(this.file, 'utf8')); } catch { return []; }
  }

  _save() {
    const tmp = this.file + '.tmp';
    fs.writeFileSync(tmp, JSON.stringify(this.schedules, null, 2));
    fs.renameSync(tmp, this.file);
  }

  start() {
    if (this.timer) return;
    this.timer = setInterval(() => this.tick(), this.tickMs);
    this.timer.unref();
    this.logger.info('SCHEDULER_STARTED', `Scheduler started with ${this.schedules.length} schedule(s)`);
  }

  stop() { if (this.timer) clearInterval(this.timer); this.timer = null; }

  list() { return this.schedules.map((s) => ({ ...s, running: this.running.has(s.id) })); }

  _find(id) {
    const s = this.schedules.find((x) => x.id === id);
    if (!s) throw new AppError(404, 'NOT_FOUND', 'Schedule not found');
    return s;
  }

  add({ label, intervalSec, verifyAfter = true }) {
    const n = Number(intervalSec);
    if (!Number.isInteger(n) || n < MIN_INTERVAL || n > MAX_INTERVAL) {
      throw new AppError(400, 'BAD_INTERVAL', `Interval must be a whole number between ${MIN_INTERVAL} and ${MAX_INTERVAL} seconds`);
    }
    const s = {
      id: 'sch-' + crypto.randomBytes(3).toString('hex'),
      label: String(label || 'Scheduled backup').slice(0, 60),
      intervalSec: n,
      verifyAfter: Boolean(verifyAfter),
      enabled: true,
      createdAt: new Date().toISOString(),
      nextRun: new Date(Date.now() + n * 1000).toISOString(),
      lastRun: null, lastStatus: null, lastError: null, lastBackupId: null, runCount: 0,
    };
    this.schedules.push(s);
    this._save();
    this.logger.info('SCHEDULE_ADDED', `Schedule "${s.label}" added: every ${n}s`, { id: s.id });
    return s;
  }

  setEnabled(id, enabled) {
    const s = this._find(id);
    s.enabled = Boolean(enabled);
    if (s.enabled) s.nextRun = new Date(Date.now() + s.intervalSec * 1000).toISOString();
    this._save();
    this.logger.info('SCHEDULE_TOGGLED', `Schedule "${s.label}" ${s.enabled ? 'resumed' : 'paused'}`, { id });
    return s;
  }

  remove(id) {
    const s = this._find(id);
    this.schedules = this.schedules.filter((x) => x.id !== id);
    this._save();
    this.logger.info('SCHEDULE_REMOVED', `Schedule "${s.label}" removed`, { id });
  }

  tick() {
    const now = Date.now();
    for (const s of this.schedules) {
      if (s.enabled && !this.running.has(s.id) && Date.parse(s.nextRun) <= now) {
        this.runNow(s.id).catch(() => { /* already logged */ });
      }
    }
  }

  async runNow(id) {
    const s = this._find(id);
    if (this.running.has(id)) throw new AppError(409, 'BUSY', 'Schedule is already running');
    this.running.add(id);
    try {
      const m = await this.manager.createBackup({ label: s.label, trigger: 'scheduled' });
      s.lastBackupId = m.id;
      s.lastStatus = 'SUCCESS';
      s.lastError = null;
      if (s.verifyAfter) {
        const v = await this.manager.verifyBackup(m.id);
        if (v.status !== 'VERIFIED') s.lastStatus = 'VERIFY_FAILED';
      }
    } catch (e) {
      s.lastStatus = 'FAILED';
      s.lastError = e.message;
    } finally {
      s.lastRun = new Date().toISOString();
      s.runCount += 1;
      s.nextRun = new Date(Date.now() + s.intervalSec * 1000).toISOString();
      this.running.delete(id);
      this._save();
    }
    return s;
  }
}

module.exports = Scheduler;
