'use strict';
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const Logger = require('./logger');
const BackupManager = require('./backupManager');
const Scheduler = require('./scheduler');
const { AppError } = require('./errors');

const MIME = {
  '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8', '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml', '.ico': 'image/x-icon', '.png': 'image/png',
};
const MAX_BODY = 1024 * 1024 + 4096;

function readBody(req) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    let size = 0;
    req.on('data', (c) => {
      size += c.length;
      if (size > MAX_BODY) { reject(new AppError(413, 'TOO_LARGE', 'Request body too large')); req.destroy(); return; }
      chunks.push(c);
    });
    req.on('end', () => {
      if (!chunks.length) return resolve({});
      try { resolve(JSON.parse(Buffer.concat(chunks).toString('utf8'))); }
      catch { reject(new AppError(400, 'BAD_JSON', 'Request body is not valid JSON')); }
    });
    req.on('error', reject);
  });
}

function send(res, status, payload) {
  const body = JSON.stringify(payload);
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
  res.end(body);
}

function createApp({ dataDir, publicDir = path.join(__dirname, '..', 'public'), maxBackups = 50, tickMs = 1000 }) {
  const logger = new Logger(path.join(dataDir, 'logs'));
  const manager = new BackupManager({ dataDir, logger, maxBackups });
  const scheduler = new Scheduler({ dataDir, manager, logger, tickMs });

  const routes = [];
  const route = (method, pattern, handler) => routes.push({ method, re: new RegExp('^' + pattern + '$'), handler });

  route('GET', '/api/status', async () => ({ ...(await manager.stats()), time: new Date().toISOString(), schedules: scheduler.list().length }));

  route('GET', '/api/source', async () => manager.listSource());
  route('POST', '/api/source', async ({ body }) => manager.writeSourceFile(body.name, body.content));
  route('DELETE', '/api/source', async ({ query }) => { await manager.deleteSourceFile(query.get('name')); return { ok: true }; });

  route('GET', '/api/backups', async () => manager.listBackups());
  route('POST', '/api/backups', async ({ body }) => manager.createBackup({ label: body.label, trigger: 'manual' }));
  route('GET', '/api/backups/([^/]+)', async ({ params }) => manager.getBackup(params[0]));
  route('DELETE', '/api/backups/([^/]+)', async ({ params }) => { await manager.deleteBackup(params[0]); return { ok: true }; });
  route('POST', '/api/backups/([^/]+)/verify', async ({ params }) => manager.verifyBackup(params[0]));
  route('POST', '/api/backups/([^/]+)/corrupt', async ({ params, body }) => manager.simulateCorruption(params[0], body));
  route('POST', '/api/backups/([^/]+)/restore', async ({ params, body }) => manager.restoreBackup(params[0], body));

  route('GET', '/api/schedules', async () => scheduler.list());
  route('POST', '/api/schedules', async ({ body }) => scheduler.add(body));
  route('PATCH', '/api/schedules/([^/]+)', async ({ params, body }) => scheduler.setEnabled(params[0], body.enabled));
  route('DELETE', '/api/schedules/([^/]+)', async ({ params }) => { scheduler.remove(params[0]); return { ok: true }; });
  route('POST', '/api/schedules/([^/]+)/run', async ({ params }) => scheduler.runNow(params[0]));

  route('GET', '/api/logs', async ({ query }) => {
    const kind = query.get('kind') === 'failures' ? 'failures' : 'events';
    const limit = Math.min(Math.max(parseInt(query.get('limit'), 10) || 100, 1), 500);
    return logger.read(kind, limit);
  });
  route('DELETE', '/api/logs', async ({ query }) => {
    logger.clear(query.get('kind') === 'failures' ? 'failures' : 'events');
    return { ok: true };
  });

  async function handleApi(req, res, url) {
    const match = (() => {
      for (const r of routes) {
        if (r.method !== req.method) continue;
        const m = r.re.exec(url.pathname);
        if (m) return { r, params: m.slice(1).map(decodeURIComponent) };
      }
      return null;
    })();
    if (!match) {
      const known = routes.some((r) => r.re.test(url.pathname));
      throw new AppError(known ? 405 : 404, known ? 'METHOD_NOT_ALLOWED' : 'NOT_FOUND', known ? 'Method not allowed' : 'Unknown API route');
    }
    const body = ['POST', 'PATCH', 'PUT'].includes(req.method) ? await readBody(req) : {};
    const result = await match.r.handler({ params: match.params, query: url.searchParams, body });
    send(res, 200, result);
  }

  function serveStatic(req, res, url) {
    let rel;
    try { rel = decodeURIComponent(url.pathname); } catch { rel = '/'; }
    if (rel === '/') rel = '/index.html';
    const root = path.resolve(publicDir);
    const full = path.resolve(root, '.' + rel);
    if (!full.startsWith(root + path.sep)) { res.writeHead(403); return res.end('Forbidden'); }
    fs.readFile(full, (err, data) => {
      if (err) { res.writeHead(404, { 'Content-Type': 'text/plain' }); return res.end('Not found'); }
      res.writeHead(200, { 'Content-Type': MIME[path.extname(full)] || 'application/octet-stream', 'Cache-Control': 'no-store' });
      res.end(data);
    });
  }

  const server = http.createServer(async (req, res) => {
    const url = new URL(req.url, 'http://localhost');
    try {
      if (url.pathname.startsWith('/api/')) await handleApi(req, res, url);
      else if (req.method === 'GET' || req.method === 'HEAD') serveStatic(req, res, url);
      else throw new AppError(405, 'METHOD_NOT_ALLOWED', 'Method not allowed');
    } catch (e) {
      if (e instanceof AppError) return send(res, e.status, { error: e.message, code: e.code });
      logger.error('SERVER_ERROR', `Unhandled error: ${e.message}`, { url: url.pathname });
      send(res, 500, { error: 'Internal server error', code: 'INTERNAL' });
    }
  });

  return { server, manager, scheduler, logger };
}

module.exports = { createApp };
