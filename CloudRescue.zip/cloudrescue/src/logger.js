'use strict';
const fs = require('node:fs');
const path = require('node:path');

/**
 * JSON-lines logger.
 *  events.log   -> every event (INFO, WARN, ERROR)
 *  failures.log -> only ERROR entries (the "failure log")
 */
class Logger {
  constructor(dir) {
    this.dir = dir;
    fs.mkdirSync(dir, { recursive: true });
    this.files = {
      events: path.join(dir, 'events.log'),
      failures: path.join(dir, 'failures.log'),
    };
  }

  _append(file, entry) {
    fs.appendFileSync(file, JSON.stringify(entry) + '\n');
  }

  log(level, event, message, meta = {}) {
    const entry = { time: new Date().toISOString(), level, event, message, meta };
    this._append(this.files.events, entry);
    if (level === 'ERROR') this._append(this.files.failures, entry);
    return entry;
  }

  info(event, message, meta) { return this.log('INFO', event, message, meta); }
  warn(event, message, meta) { return this.log('WARN', event, message, meta); }
  error(event, message, meta) { return this.log('ERROR', event, message, meta); }

  /** Newest first. kind = 'events' | 'failures'. */
  read(kind = 'events', limit = 200) {
    const file = this.files[kind];
    if (!file || !fs.existsSync(file)) return [];
    const lines = fs.readFileSync(file, 'utf8').split('\n').filter(Boolean);
    const out = [];
    for (let i = lines.length - 1; i >= 0 && out.length < limit; i--) {
      try { out.push(JSON.parse(lines[i])); } catch { /* skip damaged line */ }
    }
    return out;
  }

  count(kind = 'failures') {
    const file = this.files[kind];
    if (!file || !fs.existsSync(file)) return 0;
    return fs.readFileSync(file, 'utf8').split('\n').filter(Boolean).length;
  }

  clear(kind) {
    const file = this.files[kind];
    if (file) fs.writeFileSync(file, '');
  }
}

module.exports = Logger;
