# Quarterly Report

Revenue grew 12% quarter over quarter.
Key risks: supplier delays, staffing.
