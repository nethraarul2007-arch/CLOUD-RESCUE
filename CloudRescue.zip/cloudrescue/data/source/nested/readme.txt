Nested file: proves folder structure is preserved in backups and restores.
