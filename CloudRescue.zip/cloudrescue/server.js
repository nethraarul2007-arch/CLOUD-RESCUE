'use strict';
const path = require('node:path');
const { createApp } = require('./src/app');

const PORT = Number(process.env.PORT) || 3000;
const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, 'data');

const { server, scheduler, logger } = createApp({ dataDir: DATA_DIR });

server.on('error', (e) => {
  if (e.code === 'EADDRINUSE') console.error(`Port ${PORT} is already in use. Try: PORT=3001 npm start`);
  else console.error(e);
  process.exit(1);
});

server.listen(PORT, '127.0.0.1', () => {
  scheduler.start();
  logger.info('SERVER_STARTED', `CloudRescue started on port ${PORT}`);
  console.log(`CloudRescue running at http://localhost:${PORT}`);
  console.log('Press Ctrl+C to stop.');
});

function shutdown() {
  logger.info('SERVER_STOPPED', 'CloudRescue shutting down');
  scheduler.stop();
  server.close(() => process.exit(0));
  setTimeout(() => process.exit(0), 1000).unref();
}
process.on('SIGINT', shutdown);
process.on('SIGTERM', shutdown);
