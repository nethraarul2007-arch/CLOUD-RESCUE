# Project Report

**Title:** CloudRescue: Automated Backup and Disaster Recovery Manager
**Technologies:** HTML5, CSS3, JavaScript (ES2020), Node.js built-in modules (`http`, `fs`, `path`, `crypto`, `node:test`)

---

## 1. Abstract

Data loss from accidental deletion, disk faults or silent corruption can stop a business. CloudRescue is a small disaster-recovery system that copies a protected folder on a schedule, records a SHA-256 fingerprint of every file, re-checks those fingerprints on demand, and restores files only from copies that are proven intact. A browser dashboard shows backup history, runs integrity checks, simulates corruption to prove detection works, and exposes a failure log. The whole system uses only Node.js built-in modules, with no external packages.

## 2. Problem statement

Plain file copies give a false sense of safety. A backup that is silently damaged is only discovered at the moment it is needed. A reliable backup tool must (a) run automatically, (b) keep a history, (c) prove integrity, (d) detect corruption, (e) restore safely, and (f) record every failure for audit.

## 3. Objectives

1. Run backups automatically on user-defined intervals.
2. Keep a browsable history of every backup with metadata.
3. Verify integrity with SHA-256.
4. Simulate corruption (byte flip, truncation, deletion) and detect it.
5. Restore one file or a whole backup, refusing damaged copies.
6. Record all failures in a dedicated log.
7. Provide an easy web interface and use no third-party libraries.

## 4. Scope and limitations

- Protects one source folder (`data/source`); copies are stored on the same machine, so this demonstrates the mechanisms rather than off-site protection.
- Full backups only (each backup copies all files).
- The manifest itself is not signed; an attacker who can edit both a file and its manifest could hide a change. SHA-256 here detects accidental corruption, not a determined attacker.
- Schedules use fixed intervals (seconds), not cron expressions, and run only while the server is running.
- No authentication; the server binds to `127.0.0.1` for local use.

## 5. System design

See `ARCHITECTURE.md` and `architecture.svg`. The system has four layers: browser UI, HTTP/REST server, service modules, and disk storage.

### 5.1 Modules

| Module | Responsibility |
|---|---|
| `server.js` | Starts the HTTP server and scheduler, handles Ctrl+C shutdown |
| `src/app.js` | Route table, JSON parsing, static files, central error handling |
| `src/backupManager.js` | Create, list, verify, corrupt, restore, delete, prune backups |
| `src/scheduler.js` | Persisted interval schedules, 1-second tick, run now, pause, resume |
| `src/logger.js` | JSON-lines `events.log` and `failures.log` |
| `src/hashUtil.js` | Streaming SHA-256 using `crypto.createHash` |
| `public/*` | Dashboard: timeline, tables, dialogs, toasts |

### 5.2 Data design

Each backup is a folder `data/backups/bk-YYYYMMDD-HHMMSS-xxxx/` containing `files/` (copies) and `manifest.json`:

```json
{
  "id": "bk-20261022-094310-d179",
  "label": "Manual backup",
  "trigger": "manual",
  "createdAt": "2026-10-22T09:43:10.402Z",
  "algorithm": "SHA-256",
  "fileCount": 5,
  "totalSize": 450,
  "verifyStatus": "UNVERIFIED",
  "lastVerified": null,
  "files": [{ "path": "notes.txt", "size": 140, "sha256": "..." }]
}
```

`verifyStatus` is one of `UNVERIFIED`, `VERIFIED`, `CORRUPTED`.

## 6. Algorithms

**Backup.** For each source file: hash the source, copy it, hash the copy, and compare. A mismatch aborts the backup and removes the partial folder. On success the manifest is written atomically (temp file then rename) and the retention limit (default 50) prunes the oldest backups.

**Verification.** For each file listed in the manifest, stream the backup copy through SHA-256 and compare with the stored hash. Result per file: `OK`, `CORRUPTED` (hash differs) or `MISSING`. Any failure sets the backup to `CORRUPTED` and writes an `INTEGRITY_FAILURE` entry to the failure log. Time complexity is O(total bytes); memory use is constant because files are streamed.

**Corruption simulation.** `flip` XORs one random byte with `0xFF`; `truncate` cuts the file to half; `delete` removes it. The manifest is deliberately left unchanged, so detection relies purely on hashes.

**Restoration.** Each requested file is re-verified first. Healthy files are copied to the destination and re-hashed. Damaged files are `SKIPPED` and a `RESTORE_FAILED` error is logged. The default destination is `data/restored/<id>_<timestamp>`; overwriting `data/source` is an explicit option.

**Scheduling.** A 1-second `setInterval` checks every enabled schedule whose `nextRun` has passed and which is not already running, then calls `createBackup` (and optionally `verifyBackup`). The next run time is set after each run, so slow backups never overlap themselves. Schedules are saved to `data/schedules.json` so they survive restarts.

## 7. Failure logging

| Event | Level | Meaning |
|---|---|---|
| `BACKUP_FAILED` | ERROR | Empty source, copy mismatch or I/O error |
| `INTEGRITY_FAILURE` | ERROR | Verification found damaged or missing files |
| `RESTORE_FAILED` | ERROR | At least one file could not be restored |
| `SERVER_ERROR` | ERROR | Unexpected exception |
| `CORRUPTION_SIMULATED` | WARN | Test corruption was injected |
| `BACKUP_CREATED`, `VERIFY_OK`, `RESTORE_OK` | INFO | Normal operations |

ERROR entries are written to both `events.log` and `failures.log`.

## 8. Security measures

- Backup ids must match a strict pattern, which blocks directory traversal through URLs.
- File names are normalized and rejected if they contain `..` or are absolute; resolved paths must stay inside the intended folder.
- Static file serving blocks paths outside `public/`.
- Request bodies are limited to 1 MB; UI-created files are limited to 1 MB.
- The server binds to `127.0.0.1`.
- The UI builds the page with DOM methods (not `innerHTML`), preventing script injection from file names or log text.

## 9. Testing

Automated tests (`npm test`, 12 tests using `node:test`) all pass:

| # | Test | Result |
|---|---|---|
| 1 | SHA-256 known test vector for "abc" | Pass |
| 2 | Backup stores correct hashes and keeps nested folders | Pass |
| 3 | Clean backup verifies | Pass |
| 4 | Flip, truncate and delete are all detected and logged | Pass |
| 5 | Deleted source file is restored with identical content | Pass |
| 6 | Restore refuses a corrupted file but restores the others | Pass |
| 7 | Empty source fails and logs `BACKUP_FAILED` | Pass |
| 8 | Retention keeps only the newest N backups | Pass |
| 9 | Path traversal is rejected | Pass |
| 10 | Scheduler runs a due schedule and verifies it | Pass |
| 11 | Intervals under 5 seconds are rejected | Pass |
| 12 | HTTP API end to end, static page, traversal blocked | Pass |

Manual checks were also run against the live server: the scheduler created backups every 5 seconds, and the dashboard files (`/`, CSS, JS) were served with HTTP 200.

### Defects found and fixed during testing

- `npm test` initially failed on Node 22 because `node --test test/` treats a folder as a module path; fixed by naming the test file in the script.
- Shell brace expansion created a stray folder during project setup; removed.
- A redundant conditional in the response helper was simplified.

## 10. Results

CloudRescue meets every objective: automatic backups, history, SHA-256 verification, corruption detection of three types, safe restoration, and a failure log, all visible in one dashboard. A flipped single byte is always caught because SHA-256 changes completely for any change in input.

## 11. Future enhancements

- Incremental and deduplicated backups (store only changed files)
- Cron-style schedules and retention by age
- Off-site targets (another disk, network share, cloud bucket)
- Signed manifests (HMAC) to resist tampering
- Compression and encryption of backups
- Email or webhook alerts on failures
- Login and role-based access

## 12. Conclusion

CloudRescue shows the core ideas of disaster recovery in a compact, dependency-free project: back up regularly, verify with cryptographic hashes, assume failures will happen, and restore only from copies that are proven good.

## 13. References

- Node.js documentation: `http`, `fs`, `path`, `crypto`, `test` modules (nodejs.org/docs)
- NIST FIPS 180-4, Secure Hash Standard (SHA-256)
- The 3-2-1 backup rule (three copies, two media types, one off-site)
