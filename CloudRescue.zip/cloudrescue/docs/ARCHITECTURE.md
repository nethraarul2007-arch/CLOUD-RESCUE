# CloudRescue Architecture

![Architecture diagram](architecture.svg)

The image above is `docs/architecture.svg` (open it in VS Code or any browser). The same design in text form:

## Layered view

```
+--------------------------------------------------------------+
|  BROWSER   index.html | css/style.css | js/app.js            |
+--------------------------------------------------------------+
                  |  HTTP + JSON (REST /api/*)
+--------------------------------------------------------------+
|  WEB SERVER   server.js -> src/app.js (node:http)            |
|  routes | JSON body parser | static files | error handler     |
+--------------------------------------------------------------+
        |                 |                 |
+----------------+ +---------------+ +----------------+
| backupManager  | | scheduler     | | logger         |
| create, verify | | 1 s tick,     | | events.log     |
| corrupt,       | | runs due jobs | | failures.log   |
| restore, prune | | via manager   | | (ERROR only)   |
+----------------+ +---------------+ +----------------+
        |  hashUtil (SHA-256 stream)  |  errors (AppError)
+--------------------------------------------------------------+
|  DISK  data/source | data/backups/<id>/{manifest,files}      |
|        data/restored | data/logs | data/schedules.json       |
+--------------------------------------------------------------+
```

## Mermaid version (renders on GitHub or with a VS Code Mermaid extension)

```mermaid
flowchart TD
  UI[Browser dashboard<br/>HTML + CSS + JS] -->|REST JSON| API[src/app.js<br/>node:http router]
  API --> BM[backupManager.js]
  API --> SC[scheduler.js]
  API --> LG[logger.js]
  SC -->|due job| BM
  BM --> HU[hashUtil.js<br/>SHA-256]
  BM -->|errors and warnings| LG
  BM --> SRC[(data/source)]
  BM --> BK[(data/backups<br/>manifest.json + files)]
  BM --> RS[(data/restored)]
  SC --> SJ[(data/schedules.json)]
  LG --> LOGS[(data/logs<br/>events.log, failures.log)]
```

## Backup flow

```mermaid
sequenceDiagram
  participant S as Scheduler or user
  participant M as backupManager
  participant D as Disk
  S->>M: createBackup()
  loop each source file
    M->>D: hash source (SHA-256)
    M->>D: copy to backups/ID/files
    M->>D: hash copy and compare
  end
  M->>D: write manifest.json (hashes, sizes, time)
  M-->>S: backup record
```

## Verify, corrupt and restore flow

```mermaid
flowchart LR
  V[Verify] --> H[Re-hash every backup file]
  H --> C{Hash equals<br/>manifest hash?}
  C -->|yes| OK[VERIFIED + INFO log]
  C -->|no or missing| BAD[CORRUPTED + ERROR in failures.log]
  X[Corrupt simulation<br/>flip / truncate / delete] -.changes file only.-> H
  R[Restore] --> H2[Hash check before copy]
  H2 -->|OK| CP[Copy, re-hash, mark RESTORED]
  H2 -->|bad| SK[SKIPPED + RESTORE_FAILED log]
```

## Backup storage layout

```
data/backups/bk-20261022-094310-d179/
├── manifest.json     id, label, trigger, createdAt, verifyStatus, files[{path,size,sha256}]
└── files/            exact copies of the source files (folders preserved)
```

## Design decisions

- **Manifest per backup**: the expected hash is stored when the file is known to be good, so any later change is detectable.
- **Read-after-write check**: a backup is accepted only if the copy hashes the same as the source.
- **Restore never trusts a bad copy**: files are re-verified before being restored.
- **Safe restore by default**: restores go to `data/restored/<id>_<time>`; overwriting `data/source` is an explicit choice.
- **Atomic manifest writes**: write to a temp file, then rename, so a crash cannot leave half a manifest.
- **No dependencies**: only Node.js built-ins, so the project runs anywhere Node is installed.
