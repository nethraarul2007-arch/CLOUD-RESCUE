# Viva Questions and Answers

## A. Project basics

**1. What is CloudRescue?**
A backup and disaster-recovery manager. It copies a protected folder on a schedule, stores a SHA-256 hash of each file, verifies backups, simulates corruption, restores files, and logs failures.

**2. Why did you use only Node.js built-in modules?**
To keep the project portable and easy to run (no `npm install`), and to show how much Node can do natively: `http` for the server, `fs` for files, `crypto` for hashing, `path` for safe paths, `node:test` for testing.

**3. What problem does it solve?**
A backup that is silently damaged is useless, and you find out too late. CloudRescue proves integrity before you rely on a backup.

**4. What is the difference between backup and disaster recovery?**
Backup is making copies of data. Disaster recovery is the whole process of getting systems and data working again, including verifying copies and restoring them.

**5. Which layers does the architecture have?**
Browser UI, HTTP/REST server, service modules (backup manager, scheduler, logger, hash utility), and disk storage.

## B. Hashing and integrity

**6. What is SHA-256?**
A cryptographic hash function that turns any input into a fixed 256-bit (64 hex characters) fingerprint.

**7. Why is SHA-256 suitable for integrity checks?**
Changing even one bit of input changes the output completely (avalanche effect). It is practically impossible to find two different files with the same hash.

**8. Is a hash the same as encryption?**
No. Hashing is one-way and has no key; you cannot recover the file from the hash. Encryption is reversible with a key.

**9. How do you detect corruption?**
Re-hash each backup file and compare with the hash saved in `manifest.json` when the backup was created. A different hash means the file changed.

**10. Why stream the file instead of reading it fully?**
`fs.createReadStream` feeds the hash in chunks, so memory use stays constant even for very large files.

**11. What does the read-after-write check do?**
After copying, the code hashes the copy and compares it with the source hash. If they differ, the backup is aborted and logged.

**12. Can SHA-256 stop a malicious attacker?**
Not by itself. An attacker who can change both a file and the manifest can hide a change. Signing the manifest (HMAC) or storing hashes elsewhere would fix this. The project targets accidental corruption.

**13. What is a collision?**
Two different inputs with the same hash. For SHA-256 none are known, so collisions are not a practical concern here.

## C. Backups and scheduling

**14. How is a backup stored?**
In `data/backups/<id>/` with a `files/` folder of copies and a `manifest.json` listing paths, sizes and SHA-256 hashes.

**15. How are backup ids generated?**
`bk-` + UTC date and time + 4 random hex characters, e.g. `bk-20261022-094310-d179`. They sort by time and are validated with a regex.

**16. How does the scheduler work?**
A `setInterval` ticks every second, checks each enabled schedule whose `nextRun` time has passed, and runs a backup. After each run it sets the next run time.

**17. How do you stop overlapping runs?**
A `Set` of running schedule ids; a schedule already running is skipped until it finishes.

**18. Do schedules survive a restart?**
Yes. They are saved in `data/schedules.json` using a temp file plus rename.

**19. What is retention?**
A limit on how many backups to keep (default 50). Older ones are removed automatically to save space.

**20. Full vs incremental backup?**
Full copies every file each time (used here, simple and easy to restore). Incremental copies only changes (smaller, but a restore needs a chain of backups).

**21. Why use `setInterval` and not cron?**
It needs no dependencies and works on every OS. A cron-style parser is listed as future work.

## D. Corruption and restore

**22. How do you simulate corruption?**
Three ways: flip one byte (XOR 0xFF), truncate the file to half, or delete it. The manifest is left unchanged so the system must detect the damage by hashing.

**23. What are the verification states of a file?**
`OK`, `CORRUPTED` (hash differs) and `MISSING` (file not found).

**24. How does restore protect you?**
It re-verifies each file first and refuses to restore a damaged copy, so bad data never replaces good data.

**25. Why restore to a separate folder by default?**
To avoid overwriting current data by mistake. Overwriting `data/source` is an explicit option with a confirmation.

**26. What if only some files are corrupted?**
Healthy files are still restored, damaged ones are marked `SKIPPED`, and the failure is logged.

**27. What are RTO and RPO?**
RPO (recovery point objective) is how much data you can afford to lose, set by backup frequency. RTO (recovery time objective) is how long recovery may take. Here the schedule interval controls RPO.

## E. Logging, security and testing

**28. What logs does the system keep?**
`events.log` (everything) and `failures.log` (ERROR entries only), in JSON-lines format, one record per line.

**29. Why JSON-lines?**
Appending is simple and safe, each line is independent, and it is easy to parse and search.

**30. How do you prevent path traversal?**
Backup ids must match a strict regex; file names are normalized and rejected if they contain `..` or are absolute; resolved paths must stay inside the intended folder.

**31. How do you prevent script injection in the UI?**
The UI creates elements with DOM methods and `textContent`-style text nodes instead of `innerHTML`.

**32. Why does the server bind to 127.0.0.1?**
There is no login, so it must only be reachable from the local machine.

**33. How was the project tested?**
12 automated tests with `node:test` (hash vector, all corruption modes, restore, retention, scheduler, traversal, full HTTP flow) plus manual runs against the live server.

**34. What does an atomic write mean here?**
Write to `file.tmp`, then rename over the real file. Rename is atomic on the same disk, so readers never see a half-written manifest.

**35. What is the 3-2-1 rule, and does CloudRescue follow it?**
Three copies, on two media types, one off-site. CloudRescue stores backups on the same machine, so it demonstrates the mechanisms but does not meet 3-2-1; off-site targets are future work.

## F. Extension questions

**36. How would you add encryption?**
Use `crypto.createCipheriv` with AES-256-GCM when copying files into the backup, and decrypt on restore. Hash the ciphertext for integrity.

**37. How would you add email alerts?**
Hook into `logger.error`, and send a message through SMTP or a webhook when an ERROR is written.

**38. How would you make it scale to huge folders?**
Incremental backups with a hash index, hashing in worker threads, and storing unique file contents once (deduplication).

**39. What would you change to resist tampering?**
Sign each manifest with an HMAC using a secret key kept outside the backup folder.

**40. What was the hardest bug you fixed?**
Examples to mention: `npm test` failing on Node 22 because the test folder was passed as a module path, and making sure restore never copies a corrupted file.
