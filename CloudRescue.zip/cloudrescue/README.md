# CloudRescue: Automated Backup and Disaster Recovery Manager

CloudRescue protects a folder of files with automatic backups, proves each backup is intact using SHA-256 hashes, simulates data corruption, and restores files safely after a disaster.

It uses **only** HTML, CSS, JavaScript and Node.js built-in modules (`http`, `fs`, `path`, `crypto`). There is nothing to download with `npm install`.

## Requirements

- Node.js 18 or newer (check with `node -v`)
- Any modern browser (Chrome, Edge, Firefox)

## Run it (exact commands)

Open the folder in VS Code (`File > Open Folder`), open the integrated terminal (`View > Terminal`) and run:

```bash
node -v
npm start
```

Open **http://localhost:3000** in your browser. Stop the server with `Ctrl + C`.

Other commands:

```bash
npm test                 # run the 12 automated tests
npm run dev              # restart automatically when code changes
PORT=3001 npm start      # use another port (macOS / Linux / Git Bash)
```

Windows PowerShell: `$env:PORT=3001; npm start`   Windows cmd: `set PORT=3001 && npm start`

You can also press `F5` in VS Code and choose **Run CloudRescue**.

## 2-minute demo (good for a viva)

1. Click **Back up now**. A new block appears on the timeline.
2. Click **Verify** on it. Status becomes **VERIFIED** (green).
3. Click **Details**, pick a corruption type, click **Corrupt** next to `report.md`.
4. Click **Verify SHA-256** again. Status becomes **CORRUPTED** (red) and the file is flagged.
5. Open **Logs > Failure log**. The integrity failure is recorded.
6. Click **Restore all files**. Healthy files are restored; the corrupted one is refused.
7. Open **Source files**, delete a file (simulated disaster), then restore it from a healthy backup using **Overwrite data/source**.
8. Open **Schedules**, add a schedule every 10 seconds and watch new backups appear automatically.

## Features

| Requirement | Where it is implemented |
|---|---|
| Scheduled backups | `src/scheduler.js` (interval scheduler, pause/resume, run now, verify after backup) |
| Backup history | `src/backupManager.js` (`listBackups`) and the Backups tab |
| SHA-256 integrity verification | `src/hashUtil.js`, `verifyBackup()` (streams every file and compares with the manifest) |
| Corruption detection simulation | `simulateCorruption()` flips a byte, truncates, or deletes a backup file; the next verify detects it |
| File restoration | `restoreBackup()` restores all files or one file; corrupted copies are refused |
| Failure logs | `src/logger.js` writes `data/logs/failures.log` (errors only) and `events.log` (everything) |

## Folder structure

```
cloudrescue/
├── server.js                 Entry point (starts HTTP server + scheduler)
├── package.json
├── README.md
├── src/
│   ├── app.js                HTTP server, REST routes, static file serving
│   ├── backupManager.js      Backup, verify, corrupt, restore, retention
│   ├── scheduler.js          Interval scheduler (persisted in data/schedules.json)
│   ├── logger.js             JSON-lines event and failure logs
│   ├── hashUtil.js           Streaming SHA-256
│   └── errors.js             AppError (HTTP status + code)
├── public/
│   ├── index.html            Web dashboard
│   ├── css/style.css
│   └── js/app.js
├── data/
│   ├── source/               Files being protected (sample files included)
│   ├── backups/              One folder per backup: manifest.json + files/
│   ├── restored/             Safe restore destination
│   └── logs/                 events.log, failures.log
├── test/cloudrescue.test.js  12 automated tests (node:test)
├── docs/
│   ├── REPORT.md             Project report
│   ├── ARCHITECTURE.md       Architecture diagrams
│   ├── architecture.svg      Architecture diagram image
│   └── VIVA.md               Viva questions and answers
└── .vscode/                  Launch and task configs
```

## REST API

| Method | Route | Purpose |
|---|---|---|
| GET | `/api/status` | Dashboard numbers |
| GET, POST, DELETE | `/api/source` | List, save (`{name, content}`), delete (`?name=`) source files |
| GET, POST | `/api/backups` | History / create backup (`{label}`) |
| GET, DELETE | `/api/backups/:id` | Details / delete |
| POST | `/api/backups/:id/verify` | SHA-256 verification |
| POST | `/api/backups/:id/corrupt` | `{file?, mode}` where mode is `flip`, `truncate` or `delete` |
| POST | `/api/backups/:id/restore` | `{file?, target}` where target is `restored` or `source` |
| GET, POST | `/api/schedules` | List / add `{label, intervalSec, verifyAfter}` |
| PATCH, DELETE | `/api/schedules/:id` | Pause or resume `{enabled}` / remove |
| POST | `/api/schedules/:id/run` | Run a schedule immediately |
| GET, DELETE | `/api/logs?kind=failures` | Read / clear logs (`kind` is `failures` or `events`) |

## Troubleshooting

- **Port 3000 already in use**: run on another port, e.g. `PORT=3001 npm start`.
- **`node` is not recognized**: install Node.js LTS from nodejs.org and reopen VS Code.
- **Empty source folder**: backups fail on purpose and the failure is logged. Add a file in the Source files tab.
- **Reset everything**: stop the server and delete the contents of `data/backups`, `data/logs`, `data/restored` and the file `data/schedules.json`.

## Security notes

The server listens on `127.0.0.1` only, validates backup ids, blocks `..` path traversal in file names and static files, and limits request bodies to 1 MB. It has no login, so it is meant for local use, not for the public internet.
