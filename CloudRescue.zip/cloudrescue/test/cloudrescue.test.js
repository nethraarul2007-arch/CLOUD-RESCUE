'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { createApp } = require('../src/app');
const { sha256Buffer } = require('../src/hashUtil');

function makeEnv() {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'cloudrescue-test-'));
  fs.mkdirSync(path.join(dir, 'source', 'nested'), { recursive: true });
  fs.writeFileSync(path.join(dir, 'source', 'a.txt'), 'alpha');
  fs.writeFileSync(path.join(dir, 'source', 'b.txt'), 'bravo bravo bravo');
  fs.writeFileSync(path.join(dir, 'source', 'nested', 'c.txt'), 'charlie');
  return { dir, ...createApp({ dataDir: dir, tickMs: 100, maxBackups: 5 }) };
}
const cleanup = (env) => fs.rmSync(env.dir, { recursive: true, force: true });

test('sha256 matches a known vector', () => {
  assert.equal(sha256Buffer(Buffer.from('abc')), 'ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad');
});

test('backup records correct SHA-256 hashes and preserves folders', async () => {
  const env = makeEnv();
  const m = await env.manager.createBackup({ label: 't' });
  assert.equal(m.fileCount, 3);
  assert.equal(m.files.find((f) => f.path === 'a.txt').sha256, sha256Buffer(Buffer.from('alpha')));
  assert.ok(m.files.some((f) => f.path === 'nested/c.txt'));
  assert.ok(fs.existsSync(path.join(env.dir, 'backups', m.id, 'files', 'nested', 'c.txt')));
  cleanup(env);
});

test('verify passes on a clean backup', async () => {
  const env = makeEnv();
  const m = await env.manager.createBackup();
  const v = await env.manager.verifyBackup(m.id);
  assert.equal(v.status, 'VERIFIED');
  assert.equal(v.failed, 0);
  cleanup(env);
});

test('every corruption mode is detected and logged as a failure', async () => {
  for (const mode of ['flip', 'truncate', 'delete']) {
    const env = makeEnv();
    const m = await env.manager.createBackup();
    await env.manager.simulateCorruption(m.id, { file: 'b.txt', mode });
    const v = await env.manager.verifyBackup(m.id);
    assert.equal(v.status, 'CORRUPTED', mode);
    assert.equal(v.failed, 1, mode);
    assert.equal(v.results.find((r) => r.path === 'b.txt').status, mode === 'delete' ? 'MISSING' : 'CORRUPTED');
    assert.ok(env.logger.read('failures').some((l) => l.event === 'INTEGRITY_FAILURE'));
    cleanup(env);
  }
});

test('restore recovers a deleted source file with identical content', async () => {
  const env = makeEnv();
  const m = await env.manager.createBackup();
  fs.unlinkSync(path.join(env.dir, 'source', 'a.txt'));
  const r = await env.manager.restoreBackup(m.id, { file: 'a.txt', target: 'source' });
  assert.equal(r.ok, true);
  assert.equal(fs.readFileSync(path.join(env.dir, 'source', 'a.txt'), 'utf8'), 'alpha');
  cleanup(env);
});

test('restore refuses corrupted files but restores healthy ones', async () => {
  const env = makeEnv();
  const m = await env.manager.createBackup();
  await env.manager.simulateCorruption(m.id, { file: 'a.txt', mode: 'flip' });
  const r = await env.manager.restoreBackup(m.id, { target: 'restored' });
  assert.equal(r.ok, false);
  assert.equal(r.restored, 2);
  assert.equal(r.failed, 1);
  assert.equal(r.results.find((x) => x.path === 'a.txt').status, 'SKIPPED');
  assert.ok(env.logger.read('failures').some((l) => l.event === 'RESTORE_FAILED'));
  cleanup(env);
});

test('backup of an empty source fails and is logged', async () => {
  const env = makeEnv();
  fs.rmSync(path.join(env.dir, 'source'), { recursive: true, force: true });
  fs.mkdirSync(path.join(env.dir, 'source'));
  await assert.rejects(() => env.manager.createBackup(), { code: 'NO_SOURCE_FILES' });
  assert.ok(env.logger.read('failures').some((l) => l.event === 'BACKUP_FAILED'));
  assert.equal((await env.manager.listBackups()).length, 0);
  cleanup(env);
});

test('retention keeps only maxBackups newest backups', async () => {
  const env = makeEnv();
  for (let i = 0; i < 7; i++) await env.manager.createBackup({ label: `n${i}` });
  assert.equal((await env.manager.listBackups()).length, 5);
  cleanup(env);
});

test('path traversal is rejected', async () => {
  const env = makeEnv();
  await assert.rejects(() => env.manager.writeSourceFile('../evil.txt', 'x'), { code: 'BAD_PATH' });
  await assert.rejects(() => env.manager.getBackup('../../etc'), { code: 'BAD_ID' });
  const m = await env.manager.createBackup();
  await assert.rejects(() => env.manager.restoreBackup(m.id, { file: '../x' }), { code: 'NOT_FOUND' });
  cleanup(env);
});

test('scheduler runs a due schedule automatically', async () => {
  const env = makeEnv();
  const s = env.scheduler.add({ label: 'auto', intervalSec: 5, verifyAfter: true });
  s.nextRun = new Date(Date.now() - 1000).toISOString(); // make it due now
  env.scheduler.start();
  await new Promise((r) => setTimeout(r, 700));
  env.scheduler.stop();
  const list = await env.manager.listBackups();
  assert.equal(list.length, 1);
  assert.equal(list[0].trigger, 'scheduled');
  assert.equal(list[0].verifyStatus, 'VERIFIED');
  assert.equal(env.scheduler.list()[0].lastStatus, 'SUCCESS');
  cleanup(env);
});

test('scheduler rejects intervals below 5 seconds', () => {
  const env = makeEnv();
  assert.throws(() => env.scheduler.add({ intervalSec: 1 }), { code: 'BAD_INTERVAL' });
  cleanup(env);
});

test('HTTP API end-to-end', async () => {
  const env = makeEnv();
  await new Promise((r) => env.server.listen(0, '127.0.0.1', r));
  const base = `http://127.0.0.1:${env.server.address().port}`;
  const call = async (method, url, body) => {
    const res = await fetch(base + url, { method, headers: { 'Content-Type': 'application/json' }, body: body ? JSON.stringify(body) : undefined });
    return { status: res.status, data: await res.json() };
  };
  let r = await call('POST', '/api/backups', { label: 'api' });
  assert.equal(r.status, 200);
  const id = r.data.id;
  r = await call('POST', `/api/backups/${id}/corrupt`, { file: 'a.txt', mode: 'flip' });
  assert.equal(r.status, 200);
  r = await call('POST', `/api/backups/${id}/verify`);
  assert.equal(r.data.status, 'CORRUPTED');
  r = await call('GET', '/api/logs?kind=failures');
  assert.ok(r.data.length >= 1);
  r = await call('GET', '/api/backups/not-an-id');
  assert.equal(r.status, 400);
  r = await call('GET', '/api/nothing');
  assert.equal(r.status, 404);
  const page = await fetch(base + '/');
  assert.equal(page.status, 200);
  assert.match(await page.text(), /CloudRescue/);
  const evil = await fetch(base + '/..%2f..%2fpackage.json');
  assert.ok([403, 404].includes(evil.status));
  await new Promise((res) => env.server.close(res));
  cleanup(env);
});
